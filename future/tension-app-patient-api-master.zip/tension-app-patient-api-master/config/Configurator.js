'use strict';

const config = require("./config.json");

module.exports = {
    "server":{
        "port": process.env.PORT || config.server.port || 3000
    },
    "database":{
        "username": process.env.DB_USER || config.database.username || "root",
        "password": process.env.DB_PASS || config.database.password ||"",
        "database": process.env.DB_NAME || config.database.database ||"tensiondb2",
        "connection" : {
            "host": process.env.DB_HOST || config.database.connection.host || "127.0.0.1",
            "port": process.env.DB_PORT || config.database.connection.port ||3306,
            "dialect": "mysql"
          }
    },
    "queueSystem":{
        "enabled": process.env.QUEUE_ENABLED || config.queueSystem.enabled || false,
        "rabbitmq":{
            "username": process.env.RABBITMQ_USER || config.queueSystem.rabbitmq.username ||"root",
            "password": process.env.RABBITMQ_PASS || config.queueSystem.rabbitmq.password ||"",
            "url": process.env.RABBITMQ_URL || config.queueSystem.rabbitmq.url ||"127.0.0.1",
            "vhost": process.env.RABBITMQ_VHOST || config.queueSystem.rabbitmq.vhost ||"/"
        },
        "queues":{
            "measures": process.env.MEASURES_QUEUE || config.queueSystem.queues.measures || "measure_queue"
        }
    },
    "jwt":{
        "secret": process.env.JWT_SECRET || config.jwt.secret || "SUPERSECRET",
        "refreshSecret": process.env.JWT_REFRESH_SECRET || config.jwt.refreshSecret || "SUPERREFRESHSECRET",
    }
}