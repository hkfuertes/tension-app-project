import jwt from 'jsonwebtoken';

const Models = require('./model');

const config = require('./config/Configurator');

exports.createToken = function (user) {
  return jwt.sign({
    userId: user.id,
    userEmail: user.email,
    userName: user.name,
    userLastName: user.lastName
  }, config.jwt.secret, {
    expiresIn: 60 * 24 //24h
  })
}

exports.createRefreshToken = function (user) {
  return jwt.sign({
    userId: user.id
  }, config.jwt.refreshSecret)
}

exports.verifyToken = function (req, res, next) {
  var token = req.body.token
    || req.query.token
    || req.headers['x-access-token']
    || req.headers['authorization'];

    if(token != undefined)
      token = token.replace("Bearer ", "").replace("bearer ","");

  if (token) {
    jwt.verify(token, config.jwt.secret, function (err, decoded) {
      if (err) {
        res.json({ 'error': 'Failed to authenticate token.' });
      } else {

        Models.PatientUser.findOne({
          where: {
            id: decoded.userId
          }
        }).then(function(patientUser,err){
          Models.Patient.findOne({
            where: {
              id: patientUser.id
            }
          }).then(function(patient){
            req.currentUser = {
              "patientUser": patientUser,
              "patient": patient
            }
            next();
          });
        });
      }
    });
  } else {
    res.json({ 'error': 'Token not provided.' });
  }
};