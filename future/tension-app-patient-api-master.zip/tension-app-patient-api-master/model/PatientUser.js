"use strict";
module.exports = function (sequelize, Datatypes) {
  var patient = sequelize.define('PatientUser', {
    name: Datatypes.STRING,
    lastName:{
      field: "lastName",
      type: Datatypes.STRING
    },
    email: Datatypes.STRING,
    password: Datatypes.STRING,
    deleted: Datatypes.BOOLEAN,

  }, {
    tableName: 'patients',
    timestamps: false,
    underscored: true
  });

  return patient;
}