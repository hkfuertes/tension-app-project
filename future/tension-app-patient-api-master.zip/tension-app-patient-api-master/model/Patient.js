"use strict";
module.exports = function (sequelize, Datatypes) {
  var patient = sequelize.define('Patient', {
    gender: Datatypes.STRING,
    birthday: Datatypes.DATE,
    height: Datatypes.DOUBLE,
    treatment: Datatypes.STRING,
    limit_systolic: Datatypes.INTEGER,
    limit_diastolic: Datatypes.INTEGER,
    rythm_type: Datatypes.INTEGER,
    
    doctor_id: Datatypes.INTEGER,
  }, {
    tableName: 'patients_info',
    timestamps: false,
    underscored: true
  });

  return patient;
}