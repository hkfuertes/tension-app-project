"use strict";
module.exports = function (sequelize, Datatypes) {
  var doctor = sequelize.define('Doctor', {
    name: Datatypes.STRING,
    lastName:{
      field: "lastName",
      type: Datatypes.STRING
    },
    email: Datatypes.STRING,
  }, {
    tableName: 'doctors',
    timestamps: false,
    underscored: true
  });

  return doctor;
}