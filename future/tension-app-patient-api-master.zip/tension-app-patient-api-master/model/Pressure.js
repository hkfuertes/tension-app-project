"use strict";
module.exports = function (sequelize, Datatypes) {
  var pressure = sequelize.define('Pressure', {
    timestamp: Datatypes.DATE,
    patient_id: Datatypes.INTEGER,
    high: Datatypes.INTEGER,
    low: Datatypes.INTEGER,
    pulse: Datatypes.INTEGER
  }, {
    tableName: 'pressures',
    timestamps: false,
    underscored: true
  });

  pressure.removeAttribute('id');

  return pressure;
}