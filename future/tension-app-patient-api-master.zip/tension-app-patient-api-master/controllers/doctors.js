import express from 'express';

const AuthHelper = require('../authHelper.js');
const Models = require('../model');

const routes  = express.Router({ mergeParams: true });

//routes.use(auth.verifyToken);

routes.route('/').get(AuthHelper.verifyToken, function(req,res,next){
    Models.Doctor.findOne({
        where: {
            id: req.currentUser.patient.doctor_id
        }
    }).then(function(doctor){
        res.send({
            "result": "success",
            "data": doctor
        });
    })

});

module.exports = routes;
export default routes;