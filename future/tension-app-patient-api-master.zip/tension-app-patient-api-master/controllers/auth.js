import express from 'express';

const AuthHelper = require('../authHelper.js');

const Models = require('../model');

const routes = express.Router();

const tokenList = {}

routes.route('/auth').post(function (req, res, next) {
    console.log(req.body);
    Models.PatientUser.findOne({
        where: {
            email: req.body.email,
            password: req.body.password
        }
    })
        .then(function (user, err) {
            if (err) throw err;

            if (!user) {
                res.status(401).json({"failed": "Authentication failed."})
            } else if (user) {
                var refresh_token = AuthHelper.createRefreshToken(user);
                tokenList[refresh_token] = user;
                res.json({
                    "result": "success",
                    "access_token": AuthHelper.createToken(user),
                    "refresh_token": refresh_token,
                });
            }
        });

});

routes.route('/refresh').post(function (req, res, next) {
    const refresh_token = req.body.token 
    || req.query.token 
    || req.headers['x-refresh-token']
    || req.headers['authorization'];
    
    if(refresh_token != undefined)
        refresh_token = refresh_token.replace("Bearer ", "").replace("bearer ","");

    if(refresh_token && refresh_token in tokenList){
        res.json({
            "result": "success",
            "access_token": AuthHelper.createToken(tokenList[refresh_token]),
        });
    }else
        res.status(401).json({"failed":"refresh_token not received, or not generated!"})

});

module.exports = routes;

export default routes;