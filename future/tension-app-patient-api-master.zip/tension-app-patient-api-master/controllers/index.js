import express from 'express';

import auth from './auth.js';
import users from './patients.js';
import doctor from './doctors.js'
import measures from './measures.js';

const routes  = express.Router();

routes.use('/', auth);
routes.use('/patient', users);
routes.use('/doctor', doctor);
routes.use('/measures',measures)


module.exports = routes;

export default routes;