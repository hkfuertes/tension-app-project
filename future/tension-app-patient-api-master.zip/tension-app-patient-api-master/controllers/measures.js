import express from 'express';
const rmqService = require('../config/RabbitService.js');
const AuthHelper = require('../authHelper.js');
const config = require('../config/Configurator');

const Models = require("../model");
const routes = express.Router({ mergeParams: true });
routes.use(AuthHelper.verifyToken);

routes.route('/pressure').get(async function (req, res, next) {
    var patients = await Models.Pressure.findAll({
        where: {
            patient_id: req.currentUser.patient.id
        }
    });
    res.json({
        "result": "success",
        "data": patients
    });
});

routes.route('/pressure').post(async function (req, res, next) {
    if (!('high' in req.body) || !('low' in req.body) || !('pulse' in req.body))
        res.json({
            result: "failed",
            detail: "high, low and pulse are required in body!"
        });

    var object = {
        'timestamp': new Date(),
        'patient_id': req.currentUser.patient.id,
        'high': req.body.high,
        'low': req.body.low,
        'pulse': req.body.pulse
    };

    if (config.queueSystem.enabled) {
        var msg = {
            'command': "MEASURE_INSERT",
            'type': "PRESSURE",
            'data': object
        }

        rmqService.publishToQueue(rmqService.queues.measures, JSON.stringify(msg));

    } else
        await Models.Pressure.create(object);

    res.json({
        "result": "success"
    });

});

routes.route('/weight').get(async function (req, res, next) {

    var weights = await Models.Weight.findAll({
        where: {
            patient_id: req.currentUser.patient.id
        }
    });
    res.json({
        "result": "success",
        "data": weights
    });
});


routes.route('/weight').post(async function (req, res, next) {

    if (!('weight' in req.body))
        res.json({
            result: "failed",
            detail: "weight is required in body!"
        });

    var object = {
        'timestamp': new Date(),
        'patient_id': req.currentUser.patient.id,
        'value': req.body.weight
    };

    if (config.queueSystem.enabled) {
        var msg = {
            'command': "MEASURE_INSERT",
            'type': "WEIGHT",
            'data': object
        }
        rmqService.publishToQueue(rmqService.queues.measures, JSON.stringify(msg));

    } else
        await Models.Weight.create(object);

    res.json({
        "result": "success"
    });

});

routes.route('/pulse').get(async function (req, res, next) {
    var pulses = await Models.Pressure.findAll({
        where: {
            patient_id: req.currentUser.patient.id,
            high: null,
            low: null
        }
    });
    res.json({
        "result": "success",
        "data": pulses
    });

});

routes.route('/pulse').post(async function (req, res, next) {
    if (!('pulse' in req.body))
        res.json({
            result: "failed",
            detail: "pulse is required in body!"
        });

    var object = {
        'timestamp': new Date(),
        'patient_id': req.currentUser.patient.id,
        'pulse': req.body.pulse
    };

    if (config.queueSystem.enabled) {
        var msg = {
            'command': "MEASURE_INSERT",
            'type': "PULSE",
            'data': object
        }

        rmqService.publishToQueue(rmqService.queues.measures, JSON.stringify(msg));

    } else
        await Models.Pressure.create(object);

    res.json({
        "result": "success"
    });

});

module.exports = routes;
export default routes;