import express from 'express';

const AuthHelper = require('../authHelper.js');

const routes = express.Router({ mergeParams: true });

routes.use(AuthHelper.verifyToken);

routes.route('/').get(function (req, res, next) {
    var patientUser = req.currentUser.patientUser;
    var patient = req.currentUser.patient;
    res.json(
        {
            result: "success",
            data: {
                id: patientUser.id,
                name: patientUser.name,
                lastName: patientUser.lastName,
                email: patientUser.email,
                gender: patient.gender,
                birthday: patient.birthday,
                height: patient.height,
                treatment: patient.treatment,
                limit_systolic: patient.limit_systolic,
                limit_diastolic: patient.limit_diastolic,
                rythm_type: patient.rythm_type,
                doctor_id: patient.doctor_id
            }
        });

});

routes.route('/').put(async function (req, res, next) {
    var patientUser = req.currentUser.patientUser;
    var patient = req.currentUser.patient;
    
    if ('name' in req.body)
        patientUser.name = req.body['name'];
    if ('lastName' in req.body)
        patientUser.lastName = req.body['lastName'];

    if ('birthday' in req.body)
        patient.birthday = req.body['birthday'];

    await patientUser.save();
    await patient.save();

    res.json(
        {
            result: "success",
            data: {
                id: patientUser.id,
                name: patientUser.name,
                lastName: patientUser.lastName,
                email: patientUser.email,
                gender: patient.gender,
                birthday: patient.birthday,
                height: patient.height,
                treatment: patient.treatment,
                limit_systolic: patient.limit_systolic,
                limit_diastolic: patient.limit_diastolic,
                rythm_type: patient.rythm_type,
                doctor_id: patient.doctor_id
            }
        });


});

module.exports = routes;
export default routes;