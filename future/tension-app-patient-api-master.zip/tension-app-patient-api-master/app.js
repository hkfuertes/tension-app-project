import express from 'express';
import bodyParser from 'body-parser';

import routes from './controllers';

const config = require('./config/Configurator.js');

const app = express();

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use('/', routes);

app.listen(config.server.port);
console.log('[+] Patients server started on port: ' + config.server.port);

console.log(config);

module.exports = app;