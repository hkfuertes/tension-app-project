docker run -v ${PWD}:/usr/src/service -w /usr/src/service `
    -e REDIS_URL=192.168.1.48 `
    -e MARIADB_USER=admin `
    -e MARIADB_PASSWORD=gorilafeliz `
    -e MARIADB_DATABASE=tensiondb `
    -e MARIADB_PORT=13306 `
    -e MARIADB_URL=192.168.1.48 `
    node:11 node test-db.js