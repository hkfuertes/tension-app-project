docker run -v ${PWD}:/usr/src/service -w /usr/src/service `
    -e RABBITMQ_USER=rabbitmq `
    -e RABBITMQ_PASS=rabbitmq `
    -e RABBITMQ_URL=192.168.1.48 `
    -e MARIADB_USER=admin `
    -e MARIADB_PASSWORD=gorilafeliz `
    -e MARIADB_DATABASE=tensiondb `
    -e MARIADB_URL=192.168.1.48 `
    -e MARIADB_PORT=13306 `
    -e QUEUE_NAME=measure_queue `
    node:11 npm start