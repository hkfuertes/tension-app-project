'use strict';

const { Consumer } = require('redis-smq');
const config = require("./config.js");
const models = require("./model");

models.Pressure.findAll().then(function(els){
    console.log(els);
});