'use strict';

const path = require('path');

module.exports = {
    database:{
        username: process.env.MARIADB_USER || 'root',
        password: process.env.MARIADB_PASSWORD || '',
        database: process.env.MARIADB_DATABASE || 'tensiondb',
        connection : {
            "host": process.env.MARIADB_URL || '127.0.0.1',
            "port": process.env.MARIADB_PORT || 3306,
            "dialect": "mysql"
          }
    },
    rabbitmq:{
        username: process.env.RABBITMQ_USER || 'admin',
        password: process.env.RABBITMQ_PASS || '',
        url: process.env.RABBITMQ_URL || '127.0.0.1',
        vhost: process.env.RABBITMQ_VHOST || ''
    },
    queueName: process.env.QUEUE_NAME || "measure_queue"
};