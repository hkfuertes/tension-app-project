'use strict';

var amqp = require('amqplib/callback_api');
const config = require("./config.js");
const models = require("./model");

const CONN_URL = 'amqp://' + config.rabbitmq.username
    + ':' + config.rabbitmq.password
    + '@' + config.rabbitmq.url
    + '/' + config.rabbitmq.vhost;

console.log(CONN_URL);

amqp.connect(CONN_URL, function (err, conn) {
    console.log(err);
    conn.createChannel(function (err, ch) {
        ch.consume(config.queueName, function (msg) {
            console.log(msg.content);
            var message = JSON.parse(msg.content.toString());
            console.log(message);

            if (message.command == "MEASURE_INSERT") {
                if (message.type == "PRESSURE") {
                    models.Pressure.create(message.data).then(function (pressure) {
                        console.log("Inserted: " + message.type);
                    });
                } else if (message.type == "WEIGHT") {
                    models.Weight.create(message.data).then(function (weight) {
                        console.log("Inserted: " + message.type);
                    });

                } else if (message.type == "PULSE") {
                    models.Pressure.create({
                        'timestamp': message.data.timestamp,
                        'patient_id': message.data.patient_id,
                        'high': -1,
                        'low': -1,
                        'pulse': message.data.pulse
                    }).then(function (pulse) {
                        console.log("Inserted: " + message.type);
                    });

                }
            }

        }, { noAck: true }
        );
    });
});