var test_pressure = {
    'timestamp': new Date(),
    'patient_id': 1,
    'high': 140,
    'low': 80,
    'pulse': 70
};

var test_pulse = {
    'timestamp': new Date(),
    'patient_id': 1,
    'pulse': 70
};

var test_weight = {
    'timestamp': new Date(),
    'patient_id': 1,
    'weight': 100
};

var envelope = {
    'command': "MEASURE_INSERT",
    'type': "PRESSURE | PULSE | WEIGHT",
    'data': "<measure_data>"
};