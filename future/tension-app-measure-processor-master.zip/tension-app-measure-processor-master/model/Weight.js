"use strict";
module.exports = function (sequelize, Datatypes) {
  var weight = sequelize.define('Weight', {
    timestamp: Datatypes.DATE,
    patient_id: Datatypes.INTEGER,
    weight: Datatypes.INTEGER
  }, {
    tableName: "weights",
    timestamps: false,
    underscored: true
  });

  weight.removeAttribute('id');

  return weight;
}