var RSMQWorker = require( "rsmq-worker" );
const config = require("./config.js");

var worker = new RSMQWorker( config.queueName, config );

worker.on( "message", function( message, next, id ){
    // process your message
    console.log("Message id : " + id);
    console.log(message);

    if (message.command == "MEASURE_INSERT") {
        if (message.type == "PRESSURE") {
            models.Pressure.create(message.data).then(function (pressure){
                console.log("Inserted: " + message.type);
            });
        } else if (message.type == "WEIGHT") {
            models.Weight.create(message.data).then(function (weight){
                console.log("Inserted: " + message.type);
            });
            
        } else if (message.type == "PULSE") {
            models.Pulse.create({
                'timestamp': message.data.timestamp,
                'patient_id': message.data.patientId,
                'high': -1,
                'low': -1,
                'pulse': message.data.pulse
            }).then(function (pulse){
                console.log("Inserted: " + message.type);
            });
            
        }
    }

    next()
});

// optional error listeners
worker.on('error', function( err, msg ){
    console.log( "ERROR", err, msg.id );
});
worker.on('exceeded', function( msg ){
    console.log( "EXCEEDED", msg.id );
});
worker.on('timeout', function( msg ){
    console.log( "TIMEOUT", msg.id, msg.rc );
});

worker.start();